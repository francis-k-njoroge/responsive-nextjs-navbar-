"use client"
import Navbar from "../componet/Navbar";
import TopNav from "../componet/TopNav";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div>
      {/* Top Navigation - Hidden on Small Screens */}
      <div className="top-0">
        <TopNav />
      </div>

      {/* Main Navigation */}
      <div>
        <Navbar />
      </div>

      {children}
    </div>
  );
}
