import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const menuItems = [
    { href: '/', label: 'Home', icon: '/home.png' },
    { href: '/shop', label: 'Shop', icon: '/shop.png' },
    { href: '/cart', label: 'Cart', icon: '/cart.jpg' },
    { href: '/checkout', label: 'Checkout', icon: '/checkout.png' },
  ];

  return (
    <>
      <div className="bg-white shadow-md sticky top-0 z-50">
        {/* Main Navbar */}
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center py-4">
            {/* Logo */}
            <Link href="/">
              <span className="text-2xl font-bold text-primary cursor-pointer">XYZ Furniture</span>
            </Link>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-6">
              {menuItems.slice(0, 3).map((item) => (
                <Link key={item.href} href={item.href}>
                  <span className="text-dark hover:text-primary transition-colors duration-200 cursor-pointer">
                    {item.label}
                  </span>
                </Link>
              ))}

              
              <Link href="/contact">
                <span className="text-dark hover:text-primary transition-colors duration-200 cursor-pointer">
                  Contact
                </span>
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 hover:bg-gray-100 rounded-lg"
            >
              <Image
                src="/menu.png"
                alt="Menu"
                width={24}
                height={24}
                className="cursor-pointer"
              />
            </button>
          </div>
        </div>

        {/* Mobile Menu Dropdown */}
        {/* {isMobileMenuOpen && (
           i will add menu item here eg 
          */}
      </div>

      {/* Bottom Navigation for Mobile */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg md:hidden">
        <div className="flex justify-around items-center py-2 px-4">
          {menuItems.slice(0, 5).map((item) => (
            <Link key={item.href} href={item.href}>
              <div className="flex flex-col items-center cursor-pointer">
                <Image
                  src={item.icon}
                  alt={item.label}
                  width={24}
                  height={24}
                  className="w-6 h-6 object-contain"
                />
                <span className="text-xs text-primary mt-1">{item.label}</span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </>
  );
};

export default Navbar;


