import React from 'react';
import Image from 'next/image';
const TopNav = () => {
  return (
    <div className="bg-primary text-white text-sm py-2 hidden sm:block">
      <div className="container mx-auto flex justify-between items-center px-4">
        <div className="flex space-x-4">
          <span>
            <Image
            
            src="/phone.png" // Replace with your home icon image path
            alt="Home"
            width={24}
            height={24}
              className="inline-block w-4 h-4 mr-1"
            />
            123 Street, New York
          </span>
          <span>
            <Image
               src="/message.png" // Replace with your home icon image path
               width={24}
               height={24}
              alt="Email Icon"
              className="inline-block w-4 h-4 mr-1"
            />
            Email@Example.com
          </span>
        </div>
        <div className="flex space-x-4">
          <a href="#" className="hover:text-secondary">Privacy Policy</a>
          <a href="#" className="hover:text-secondary">Terms of Use</a>
          <a href="#" className="hover:text-secondary">Sales and Refunds</a>
        </div>
      </div>
    </div>
  );
};

export default TopNav;
