const MenuItem = () => {
  return (
    <div className=''>MenuItem</div>
  );
}

export default MenuItem